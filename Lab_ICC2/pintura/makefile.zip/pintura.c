#include <stdio.h>
#include <stdlib.h>
#include "pilha.h"

typedef struct _tinta {
  int pos_x;
  int pos_y;
  char cor;

} T;


char** pinta_tudo(Pilha p, char** board, char color, long int largura, long int altura) {
  int x;
  int y;
  char temp;

  while (isEmpty(&p) != 1) {
//    printf("y: %d\n", y);
    pop(&p, &y);
    pop(&p, &x);
//    printf("*y: %d\n", y);
    temp = board[x][y];
    board[x][y] = color;
    if (board[x+1][y] == temp && (x+1) <= altura) {
      push(&p, (x+1));
      push(&p, y);

    }
    if (board[x-1][y] == temp && (x-1) > 0) {
      push(&p, (x-1));
      push(&p, y);

    }
    if (board[x][y+1] == temp && (y+1) <= largura) {
      push(&p, x);
      push(&p, (y+1));

    }
    // if (board[x][y-1] == temp && (y-1) > 0) {
    //   push(&p, x);
    //   push(&p, (y-1));
    //
    // }

  }
  return board;
}


int main(int argc, char const* argv[]) {

  long int altura, largura;

  scanf("%ld %ld", &altura, &largura);
  getchar();  // pega o \n

  char **pintura = (char**) calloc(altura, sizeof(char*));
  for (int i = 0; i < altura; i++ )  {
    pintura[i] = (char*) calloc(largura, sizeof(char));
  }
  Pilha p;

  cria_pilha(&p);

  for (int i = 0; i < altura; i++) {
    scanf("%[^\n]s", pintura[i]);
    getchar();  // pega o \n
//    printf("%d\n", i);
  }

  int k = 0;
  T tinta[500];

  while (scanf("%d %d %c", &tinta[k].pos_x, &tinta[k].pos_y, &tinta[k].cor) != EOF) {
    push(&p, tinta[k].pos_x);
    push(&p, tinta[k].pos_y);

    pintura = pinta_tudo(p, pintura, tinta[k].cor, largura, altura);

    for (int i = 0; i < altura; i++) {
      for (int j = 0; j < largura; j++) {
        printf("%c", pintura[i][j]);
      }
      printf("\n");
    }

//    printf("leu 3: %d %d %c\n", tinta[k].pos_x, tinta[k].pos_y, tinta[k].cor);
    k++;
  }

  // 
  // for (int i = 0; i < altura; i++) {
  //   for (int j = 0; j < largura; j++) {
  //     printf("%c", pintura[i][j]);
  //   }
  //   printf("\n");
  // }

  for (int i = 0; i < altura; i++) {
    free(pintura[i]);
  }
  free(pintura);

  return 0;
}
